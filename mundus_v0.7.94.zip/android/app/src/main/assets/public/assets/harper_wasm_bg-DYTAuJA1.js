const a=""+new URL("harper_wasm_bg-Y3b-Wqbx.wasm",import.meta.url).href;export{a as default};
